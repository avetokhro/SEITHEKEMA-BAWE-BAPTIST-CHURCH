SEITHEKEMA BAWE BAPTIST CHURCH WEBSITE

Files:
- index.html: the complete mobile-friendly church website.

HOW TO USE:
1. Open index.html in a web browser to preview the website.
2. Before publishing, replace the contact placeholders with the church's phone number and email.
3. Replace the gallery placeholders by editing the HTML and adding your church photos.
4. Publish free using GitHub Pages:
   - Create/sign in to a GitHub account.
   - Create a new public repository (for example: seithekema-bawe-baptist-church).
   - Upload index.html.
   - Open repository Settings > Pages.
   - Under Build and deployment, choose Deploy from a branch, select main and /(root), then Save.
   - GitHub will provide the public website address after deployment.

This is a static website; no paid hosting is required for GitHub Pages.
